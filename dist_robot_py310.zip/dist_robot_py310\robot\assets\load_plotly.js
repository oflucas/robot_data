function loadPlotlyScript() {
	const script = document.createElement('script');
	script.src = 'https://cdn.plot.ly/plotly-latest.min.js';
	document.head.appendChild(script)
}

loadPlotlyScript();