function loadPlotlyScript() {
	const script = document.createElement('script');
	// Need to manually update this version. https://cdn.plot.ly/plotly-latest.min.js is not latest.
	script.src = 'https://cdn.plot.ly/plotly-4.0.0.min.js';
	document.head.appendChild(script)
}

loadPlotlyScript();