# Pyarmor 8.5.11 (trial), 000000, 2025-10-19T14:30:51.678387
from .pyarmor_runtime import __pyarmor__
