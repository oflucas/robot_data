# Pyarmor 8.5.11 (trial), 000000, 2025-06-14T11:42:29.281823
from .pyarmor_runtime import __pyarmor__
