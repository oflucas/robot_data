# Pyarmor 8.5.11 (trial), 000000, 2025-06-15T12:28:33.203465
from .pyarmor_runtime import __pyarmor__
