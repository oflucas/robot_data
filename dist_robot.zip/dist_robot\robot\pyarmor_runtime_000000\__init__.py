# Pyarmor 8.5.11 (trial), 000000, 2025-10-26T13:54:26.935550
from .pyarmor_runtime import __pyarmor__
