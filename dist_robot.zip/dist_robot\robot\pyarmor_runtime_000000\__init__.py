# Pyarmor 8.5.11 (trial), 000000, 2025-06-22T17:36:19.103814
from .pyarmor_runtime import __pyarmor__
