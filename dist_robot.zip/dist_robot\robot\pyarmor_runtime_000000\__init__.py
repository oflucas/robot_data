# Pyarmor 8.5.11 (trial), 000000, 2025-10-25T23:52:57.146943
from .pyarmor_runtime import __pyarmor__
