# Pyarmor 8.5.11 (trial), 000000, 2025-07-05T15:39:50.220738
from .pyarmor_runtime import __pyarmor__
