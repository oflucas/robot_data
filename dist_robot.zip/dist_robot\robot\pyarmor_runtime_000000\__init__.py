# Pyarmor 8.5.11 (trial), 000000, 2025-07-05T16:11:29.950187
from .pyarmor_runtime import __pyarmor__
