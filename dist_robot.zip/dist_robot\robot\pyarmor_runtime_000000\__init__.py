# Pyarmor 8.5.11 (trial), 000000, 2025-06-01T14:32:02.665183
from .pyarmor_runtime import __pyarmor__
