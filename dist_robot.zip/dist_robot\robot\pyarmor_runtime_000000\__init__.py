# Pyarmor 8.5.11 (trial), 000000, 2025-07-05T12:23:00.877085
from .pyarmor_runtime import __pyarmor__
