# Pyarmor 8.5.11 (trial), 000000, 2025-12-28T16:28:33.899760
from .pyarmor_runtime import __pyarmor__
