# Pyarmor 8.5.11 (trial), 000000, 2025-06-01T15:06:49.602040
from .pyarmor_runtime import __pyarmor__
